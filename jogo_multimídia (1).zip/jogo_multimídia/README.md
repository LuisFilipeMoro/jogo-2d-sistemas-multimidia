# Jogo Plataforma 2D — Sistemas Multimídia

**Estudantes:** Edu Bagio, Gustavo Monteiro, Miguel Bruno, Samuel Félix  
**Professora:** Marina Carradore Sérgio  
**Disciplina:** Sistemas Multimídia

---

## Como jogar

| Tecla | Ação |
|-------|------|
| ← → (setas) | Mover o personagem |
| Espaço / ↑ | Pular |

---

## Requisitos atendidos ✅

- [x] Projeto desenvolvido na **Godot Engine 4.x**
- [x] **Camera2D** adicionada ao personagem (segue o jogador)
- [x] **4 plataformas** em alturas diferentes (mais que o mínimo de 3)
- [x] Repositório público no **GitHub**

---

## Como abrir o projeto

1. Baixe e instale o [Godot Engine 4.x](https://godotengine.org/download)
2. Abra o Godot e clique em **"Importar"**
3. Navegue até a pasta do projeto e selecione o arquivo `project.godot`
4. Clique em **"Importar e Editar"**
5. Pressione **F5** para rodar o jogo

---

## Estrutura do projeto

```
jogo_multimídia/
├── project.godot        # Configuração do projeto
├── icon.svg             # Ícone do projeto
├── scenes/
│   ├── Main.tscn        # Cena principal (mundo + plataformas)
│   └── Jogador.tscn     # Personagem com Camera2D
└── scripts/
    └── Jogador.gd       # Lógica de movimento e pulo
```
