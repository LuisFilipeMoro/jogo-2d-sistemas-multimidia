extends CharacterBody2D

const VELOCIDADE = 220.0
const FORCA_PULO = -550.0
const GRAVIDADE = 900.0

func _physics_process(delta):
	# Aplica gravidade
	if not is_on_floor():
		velocity.y += GRAVIDADE * delta

	# Pulo com Espaço, Enter ou seta pra cima
	var quer_pular = Input.is_action_just_pressed("ui_accept") or Input.is_action_just_pressed("ui_up")
	if quer_pular and is_on_floor():
		velocity.y = FORCA_PULO

	# Movimento horizontal
	var direcao = Input.get_axis("ui_left", "ui_right")
	if direcao != 0:
		velocity.x = direcao * VELOCIDADE
	else:
		velocity.x = move_toward(velocity.x, 0, VELOCIDADE)

	move_and_slide()
